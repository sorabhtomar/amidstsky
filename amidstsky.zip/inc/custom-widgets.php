<?php
	require_once get_template_directory() . '/inc/widgets/recent-posts.php';
?>